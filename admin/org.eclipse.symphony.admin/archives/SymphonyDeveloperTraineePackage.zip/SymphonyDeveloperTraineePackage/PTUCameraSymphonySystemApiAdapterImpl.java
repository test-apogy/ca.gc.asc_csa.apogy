	/**
	 * This method will return a 4x4 matrix, whose components represent
	 * the transformation (e.g. rotations, translations, etc.) from where
	 * the given operation took place to the camera's root topology node;
	 * for example, for the operation takeSnapshot(), this describes the
	 * transformation from the camera's lens to its base (e.g. root). If
	 * no transformation occurred, then the identity matrix should be
	 * returned; note that this, in fact, is what is returned by the
	 * superclass's version of this method.
	 * 
	 * @param operationCall The operation which took place
	 * @return The transformation from where the operation took place to the PTU camera's root
	 */
	@Override
	public Matrix4x4 createResultMatrix(OperationCall operationCall) 
	{
		// If the takeSnapshot() method was called
		if (operationCall.getEOperation().getOperationID() == EMFEcoreExampleCameraPackage.CAMERA___TAKE_SNAPSHOT)
		{
			// Extract the camera lens and root nodes
			Node tip = TopologyFacade.INSTANCE.findNodesByID("PTU_CAMERA_FOV",
															 getSymphonySystem().getTopologyRoot().getOriginNode()).get(0);
			Node root = TopologyFacade.INSTANCE.findNodesByID("PTU_CAMERA_ROOT",
															  getSymphonySystem().getTopologyRoot().getOriginNode()).get(0);
			
			// Determine the series of transformations that have taken place
			Matrix4d matrix4d = TopologyFacade.INSTANCE.expressInFrame(tip,	root);
			
			// Create a 4x4 Matrix with the transformation and return it
			return MathFacade.INSTANCE.createMatrix4x4(matrix4d);
		}
		// Otherwise, any other operation was called
		else
		{
			// Just return the identity matrix
			return super.createResultMatrix(operationCall);
		}
	}
