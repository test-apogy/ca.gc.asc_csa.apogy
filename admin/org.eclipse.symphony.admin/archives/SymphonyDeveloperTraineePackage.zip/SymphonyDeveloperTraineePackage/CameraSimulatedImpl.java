	@Override
	public ImageSnapshot takeSnapshot() 
	{
		// Create an image snapshot
		ImageSnapshot imageSnapshot = PTUCameraPackage.eINSTANCE.createImageSnapshot();
		
		// Set the time of the snapshot to the current date and time
		imageSnapshot.setTime(new Date());
				
		// Save a copy of the current field of view
		imageSnapshot.setFieldOfView(FOVFacade.INSTANCE.createRectangularFrustrumFieldOfView(getFieldOfView()));
					
		// Save the image in the snapshot
		imageSnapshot.setImage(null);
		
		// Update latest snapshot accordingly
		setLatestImageSnapshot(imageSnapshot);
		
		// Return the generated snapshot
		return imageSnapshot;
	}
