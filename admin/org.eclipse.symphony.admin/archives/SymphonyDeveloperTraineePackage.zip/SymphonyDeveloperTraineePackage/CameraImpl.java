
	protected static final double MAXIMUM_HORIZONTAL_FOV_DEGREES = 45;	
	protected static final double MAXIMUM_VERTICAL_FOV_DEGREES = 33.75;	
	protected static final double MIN_ZOOM = 1.0;
	protected static final double MAX_ZOOM = 10.0;
	protected static final double FOV_DEF_MINIMUM_RANGE = 0.0;
	protected static final double FOV_DEF_MAXIMUM_RANGE = 10.0;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated_NOT
	 */
	public RectangularFrustrumFieldOfView getFov() 
	{
		// If there currently is no FOV
		if(fov == null)
		{
			// Create one with certain default parameters
			fov = FOVFacade.INSTANCE.createRectangularFrustrumFieldOfView(FOV_DEF_MINIMUM_RANGE,FOV_DEF_MAXIMUM_RANGE, calculateHorizontalFOVAngle(), calculateVerticalFOVAngle());
			// Set it as the camera's FOV
			setFov(fov);
		}
		
		// Return the camera's field of view
		return fov;
	}

	@Override
	public RectangularFrustrumFieldOfView getFieldOfView() {		
		return getFov();
	}

		/**
	 * This helper method is used to calculate the horizontal angle (in
	 * radians) of the field of view.  This calculation is based on both
	 * the current zoom level (which is in [getMinimumZoom(), getMaximumZoom()])
	 * as well as a constant specifying the maximum horizontal angle.
	 * @return The horizontal field of view angle (in radians)
	 * @see #calculateVerticalFOVangle()
	 * @see #updateFov()
	 */
	protected double calculateHorizontalFOVAngle()
	{
		// Calculate and return the horizontal FOV angle
		double angle = MAXIMUM_HORIZONTAL_FOV_DEGREES / getCurrentZoom();
		return Math.toRadians(angle);
	}

	/**
	 * This helper method is used to calculated the vertical angle (in
	 * radians) of the field of view.  This calculation is based on both
	 * the current zoom level (which is in [getMinimumZoom(), getMaximumZoom()])
	 * as well as a constant specifying the maximum vertical angle.
	 * @return The vertical field of view angle (in radians)
	 * @see #calculateHorizontalFOVAngle()
	 * @see #updateFov()
	 */
	protected double calculateVerticalFOVAngle()
	{
		// Calculate and return the vertical FOV angle
		double angle =  MAXIMUM_VERTICAL_FOV_DEGREES / getCurrentZoom();
		return Math.toRadians(angle);
	}
	
	/**
	 * This helper method is used to update the both the horizontal and
	 * vertical angles (in radians) of the rectangular frustrum field of view,
	 * based on the current level of zoom.
	 * @see #calculateHorizontalFOVAngle()
	 * @see #calculateVerticalFOVAngle()
	 */
	protected void updateFov()
	{
		// Calculate the new field of view (FOV) angles and
		// update the FOV accordingly.
		getFov().setHorizontalFieldOfViewAngle(calculateHorizontalFOVAngle());
		getFov().setVerticalFieldOfViewAngle(calculateVerticalFOVAngle());
	}
